package com.api.Messagerie.Basique;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BasiqueApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasiqueApplication.class, args);
	}

}
