package com.api.Messagerie.Basique;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BasiqueApplicationTests {

	@Test
	void contextLoads() {
	}

}
